nohup java -jar /home/music-box/file-exchanging/music-box-file-exchanging-0.0.1-SNAPSHOT.jar
