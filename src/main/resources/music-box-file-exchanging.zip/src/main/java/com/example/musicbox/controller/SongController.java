package com.example.musicbox.controller;

import com.example.musicbox.common.NeedToken;
import com.example.musicbox.service.SongService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;

@Slf4j
@RestController
@RequestMapping("/song")
public class SongController {
    @Autowired
    private SongService songService;

    @GetMapping("/play/guest/{song_id}")
    public void playSongGuest(@PathVariable("song_id") long songId, HttpServletResponse response) {
        songService.playSongGuest(songId, response);
    }

    @NeedToken
    @GetMapping("/play/logged/{song_id}")
    public void playSongLogged(@PathVariable("song_id") long songId, HttpServletResponse response) {
        songService.playSongLogged(songId, response);
    }

    @GetMapping("/download/guest/{song_id}")
    public void downloadSongGuest(@PathVariable("song_id") long songId, HttpServletResponse response) {
        songService.downloadSongGuest(songId, response);
    }

    @NeedToken
    @GetMapping("/download/logged/{song_id}")
    public void downloadSongLogged(@PathVariable("song_id") long songId, HttpServletResponse response) {
        songService.downloadSongLogged(songId, response);
    }
}
