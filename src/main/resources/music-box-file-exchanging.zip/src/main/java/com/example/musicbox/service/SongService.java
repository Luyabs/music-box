package com.example.musicbox.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.musicbox.entity.Song;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;

public interface SongService extends IService<Song> {

    boolean upLoadSongFile(MultipartFile songFile);                             //上传新歌曲文件

    boolean upLoadSongCover(MultipartFile songCoverFile,Long songID);           //上传（修改）歌曲封面

    void playSongGuest(long songId, HttpServletResponse response);

    void playSongLogged(long songId, HttpServletResponse response);

    void downloadSongGuest(long songId, HttpServletResponse response);

    void downloadSongLogged(long songId, HttpServletResponse response);
}
