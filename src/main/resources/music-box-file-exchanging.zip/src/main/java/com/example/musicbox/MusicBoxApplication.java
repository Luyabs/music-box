package com.example.musicbox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicBoxApplication {
	public static void main(String[] args) {
		SpringApplication.run(MusicBoxApplication.class, args);
	}

}
