package com.example.musicbox.entity.relation;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Accessors(chain = true)
@TableName("playback_record_user_song")
public class SongPlayRecord {
    @TableId(type = IdType.ASSIGN_ID)
    private Long id;

    private Long userId;

    private Long songId;

    private Integer status;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
