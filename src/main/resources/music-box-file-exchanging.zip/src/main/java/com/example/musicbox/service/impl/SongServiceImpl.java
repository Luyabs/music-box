package com.example.musicbox.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.musicbox.common.UserInfo;
import com.example.musicbox.common.exception.ServiceException;
import com.example.musicbox.entity.Song;
import com.example.musicbox.entity.relation.SongComment;
import com.example.musicbox.entity.relation.SongPlayRecord;
import com.example.musicbox.mapper.SongMapper;
import com.example.musicbox.mapper.UserMapper;
import com.example.musicbox.mapper.relation.SongCommentMapper;
import com.example.musicbox.mapper.relation.SongPlayRecordMapper;
import com.example.musicbox.service.SongService;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;

@Service
public class SongServiceImpl extends ServiceImpl<SongMapper, Song> implements SongService {
    @Autowired
    private SongMapper songMapper;
    @Autowired
    private SongCommentMapper songCommentMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private SongPlayRecordMapper songPlayRecordMapper;

    @Value("${file-url.song-base-url}")
    private String songBaseUrl;     // 音乐上传地址

    @Value("${file-url.cover-base-url}")
    private String coverBaseUrl;     // 封面上传地址

    @Override
    public boolean upLoadSongFile(MultipartFile songFile) {
        new File(songBaseUrl).mkdirs();  // 没有文件夹就创一个
        if (!userMapper.selectById(UserInfo.get()).getIsCreator())
            throw new ServiceException("你还未加入创作者，无法上传作品");

        String originFileName = songFile.getOriginalFilename();   //原文件名
        String newFileName;      //新文件名
        String prefix;           //后缀名
        File localFile;          //本地文件对象
        Song newSong;
        int index;
        List<String> songPrefix = List.of("mp3", "wav", "wma", "m4a", "flac");
        try {
            if (originFileName != null) {
                index = originFileName.lastIndexOf('.');
                prefix = originFileName.substring(index + 1);
                if (index <= 0 || !songPrefix.contains(prefix))
                    throw new ServiceException("文件格式错误");
            } else {
                throw new ServiceException("文件名错误（不能为空）");
            }
            String randomFileName = UUID.randomUUID().toString();               //服务器本地歌曲名随机
            newFileName = songBaseUrl + randomFileName + '.' + prefix;
            localFile = new File(newFileName);
            songFile.transferTo(localFile);
            //歌曲记录初始化：上传者id，后台文件路径，歌曲名默认是上传文件名,封面默认为no_picture_yet.jpg,歌手名未知
            newSong = new Song().setUserId(UserInfo.get()).
                    setFileDirectory(newFileName).
                    setSongName(originFileName.substring(0, index)).
                    setCoverPicture("src/main/resources/static/no_picture_yet.jpg").
                    setSingerName("未知");
        } catch (Exception ex) {
            log.error(ex.getMessage());
            throw new ServiceException(ex.getMessage());
        }
        return songMapper.insert(newSong) > 0;
    }

    @Override
    public boolean upLoadSongCover(MultipartFile songCoverFile, Long songID) {

        new File(coverBaseUrl).mkdirs();  // 没有文件夹就创一个

        String originFileName = songCoverFile.getOriginalFilename();   //原文件名
        String newFileName;      //新文件名
        String prefix;           //后缀名
        File localFile;          //本地文件对象
        int index;
        Song song;
        try {
            if (originFileName != null) {
                index = originFileName.lastIndexOf('.');
                prefix = originFileName.substring(index + 1);
                if (index <= 0 || !prefix.equals("jpg"))
                    throw new ServiceException("歌曲封面格式错误（只能为jpg）");
            } else {
                throw new ServiceException("文件名错误（不能为空）");
            }
            String randomFileName = UUID.randomUUID().toString();               //服务器本地歌曲封面随机
            newFileName = coverBaseUrl + randomFileName + '.' + prefix;             //重构图片名
            localFile = new File(newFileName);
            songCoverFile.transferTo(localFile);
            song = getSongById(songID);
            if (song.getStatus() < 0)
                throw new ServiceException("歌曲状态异常（删除/封禁），无法上传封面");
            if (!song.getUserId().equals(UserInfo.get()))
                throw new ServiceException("当前用户无权限修改他人歌曲");
            else
                song.setCoverPicture(newFileName);                              //若当前用户是歌曲的创建者，修改封面

        } catch (Exception ex) {
            log.error(ex.getMessage());
            throw new ServiceException(ex.getMessage());
        }
        return songMapper.updateById(song) > 0;
    }

    @Override
    public void playSongGuest(long songId, HttpServletResponse response) {
        Song songInfo = getSongById(songId);

        if (songInfo.getIsVip())
            throw new ServiceException("未登录状态不能播放VIP歌曲");

        transmitSong(songInfo, response, true);
    }

    @Override
    public void playSongLogged(long songId, HttpServletResponse response) {
        Song songInfo = getSongById(songId);

        if (songInfo.getIsVip() && !userMapper.selectById(UserInfo.get()).getIsVip() && songInfo.getUserId() != UserInfo.get())
            throw new ServiceException("本歌曲需要vip权限才能播放");  // 作者本人允许播放

        transmitSong(songInfo, response, true);
    }

    @Override
    public void downloadSongGuest(long songId, HttpServletResponse response) {
        Song songInfo = getSongById(songId);

        if (songInfo.getIsVip())
            throw new ServiceException("未登录状态不能下载VIP歌曲");

        transmitSong(songInfo, response, false);
    }

    @Override
    public void downloadSongLogged(long songId, HttpServletResponse response) {
        Song songInfo = getSongById(songId);

        if (songInfo.getIsVip() && !userMapper.selectById(UserInfo.get()).getIsVip() && songInfo.getUserId() != UserInfo.get())
            throw new ServiceException("本歌曲需要vip权限才能下载");   // 作者本人允许下载

        transmitSong(songInfo, response, false);
    }

    /**
     * 按id获取歌曲 并校验是否为null
     */
    private Song getSongById(long songId) {
        Song songInfo = songMapper.selectById(songId);
        if (songInfo == null)
            throw new ServiceException("不存在id=" + songId + "的歌曲");
        return songInfo;
    }
    private SongComment getSongCommentById(long commentId) {
        SongComment songCommentInfo = songCommentMapper.selectById(commentId);
        if (songCommentInfo == null)
            throw new ServiceException("不存在id=" + commentId + "的评论");
        return songCommentInfo;
    }


    /**
     * 通过response传输歌曲文件
     */
    @SneakyThrows
    private void transmitSong(Song songInfo, HttpServletResponse response, boolean online) {
        URL url = new URL("file:///" + songInfo.getFileDirectory());
        URLConnection conn = url.openConnection();
        InputStream inputStream = conn.getInputStream();
        String[] fileUrlSegments = songInfo.getFileDirectory().split("\\.");
        response.reset();
        response.setContentType(conn.getContentType());
        response.setHeader("Content-Disposition",
                online ? "inline; filename=" + URLEncoder.encode(songInfo.getSongName(), StandardCharsets.UTF_8)
                        : "attachment; filename=" + URLEncoder.encode(songInfo.getSongName().replace(' ', '_') + "." + fileUrlSegments[fileUrlSegments.length - 1], StandardCharsets.UTF_8)
        );
        OutputStream outputStream = response.getOutputStream();

        byte[] buffer = new byte[64];
        int len;
        while ((len = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, len);
        }
        inputStream.close();

        // 增加播放/下载记录
        if (UserInfo.isNull())      // 未登录用户不留下听歌记录
            return;
        SongPlayRecord record = new SongPlayRecord().setUserId(UserInfo.get()).setSongId(songInfo.getId());
        record.setStatus(online ? 0 : 1);
        songPlayRecordMapper.insert(record);
    }
}
