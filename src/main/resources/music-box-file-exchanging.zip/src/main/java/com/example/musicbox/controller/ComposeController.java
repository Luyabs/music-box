package com.example.musicbox.controller;

import com.example.musicbox.common.NeedToken;
import com.example.musicbox.common.Result;
import com.example.musicbox.service.SongService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


@RestController
@RequestMapping("/compose")
public class ComposeController {
    @Autowired
    private SongService songService;

    @NeedToken
    @PostMapping("/music")
    public Result upLoadSongFile(@RequestPart("songFile")MultipartFile songFile){

        boolean res = songService.upLoadSongFile(songFile);
        return res?Result.success().message("上传歌曲文件成功"):Result.error().message("上传歌曲文件失败");
    }
    @NeedToken
    @PostMapping("/cover")
    public Result upLoadSongCover(@RequestPart("songCoverFile")MultipartFile songCoverFile, @RequestParam String songID){
        Long songId  = Long.parseLong(songID);
        boolean res = songService.upLoadSongCover(songCoverFile,songId);
        return res?Result.success().message("上传歌曲封面成功"):Result.error().message("上传歌曲封面失败");
    }
}
