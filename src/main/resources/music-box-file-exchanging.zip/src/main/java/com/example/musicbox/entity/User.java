package com.example.musicbox.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;

@Data
@Accessors(chain = true)
public class User {
    @TableId
    private Long id;

    private String nickname;

    private String avatar;

    private String gender;

    private String region;

    private String birthday;

    private String signature;

    private String profession;

    private String localDownloadingDirectory;

    private Integer status;

    private Boolean isCreator;

    private Boolean isVip;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
