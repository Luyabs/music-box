kill -9 $(ps -ef | grep "music-box-file-exchanging-0.0.1-SNAPSHOT.jar" | grep -v grep | awk '{print $2}')

rm -f /home/music-box/file-exchanging/music-box-file-exchanging-0.0.1-SNAPSHOT.jar
rm -f /home/music-box/file-exchanging/nohup.out
